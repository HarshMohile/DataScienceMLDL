print ("b in")
import a
print ("b out")
x = 3
