def cal_area_triangle(length,hight):
    return 1/2*length*hight

def cal_area_sqr(length):
    return length*length


def cal_area_rec(leng,bth):
    return leng*bth

def cal_area_cir(r):
    return 3.14*r*r
